import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QDial, QSlider
from ControlClass import Control
from PyQt5.QtGui import QIcon, QFont
from threading import Thread, Event


class Window:
    app = QApplication(sys.argv)
    con = Control()

    def __init__(self, a: int = 0, b: int = 0, c: int = 0):
        pass

    def show(self, name, icon=None):
        w = QWidget()
        w.move(300, 300)
        w.setFixedSize(600, 350)
        w.setWindowTitle(name)
        if type(icon) == str:
            w.setWindowIcon(QIcon(icon))

        label = QLabel("Управление дроном", w)
        label.setFont(QFont("Arial", 18))
        label.move(30, 30)

        def dial_method():
            val = dial.value()
            print(val)


        dial = QDial(w)
        dial.setGeometry(120, 120, 120, 120)
        dial.move(50, 100)
        dial.valueChanged.connect(dial_method)

        speed = QSlider(w)
        speed.move(200, 120)
        speed.setValue(30)

        label_direction = QLabel(w, text="Направление")
        label_direction.move(50, 220)
        label_direction.setFont(QFont("Arial", 10))

        label_speed = QLabel(w, text="Скорость")
        label_speed.move(180, 220)
        label_speed.setFont(QFont("Arial", 10))

        w.show()
        self.close()

    def close(self):
        a = self.app.exec_()
        self.change_flags()
        sys.exit(a)

    def change_flags(self):
        for i in range(len(self.con.all_flags)):
            self.con.all_flags[i] = False

    def keyboard_move(self):
        thread1 = Thread(target=self.con.keyboard_move, args=(len(self.con.all_flags),))
        self.con.all_flags.append(True)
        thread1.start()

# Можно легко объявлять новые методы

if __name__ == "__main__":
    wind = Window()
    wind.keyboard_move()
    wind.show("Проект")
