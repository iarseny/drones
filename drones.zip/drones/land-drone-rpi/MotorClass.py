# библиотека для работы с GPIO RPI
import RPi.GPIO
from time import sleep

# BCM означает номер "канала Broadcom SOC" - это нумерация пинов внутри микросхемы 
GPIO.setmode(GPIO.BCM)

class Motor():
	def __init__(self, enable_driver, pul_1, pul_2):
		self.enable_driver = enable_driver
		self.pul_1 = pul_1
		self.pul_2 = pul_2
	for pin in [enable_driver, pul_1, pul_2]:
    	GPIO.setup(pin,GPIO.OUT)

    def move():
    	pass
    def stop():
    	pass

def main():
	pass

if __name__ == '__main__':
	move_forward = Motor(23,3,4)
	main()
	GPIO.cleanup()