# библиотека для работы с пинами GPIO RPI
import RPi.GPIO as GPIO
from time import sleep
# BCM означает номер "канала Broadcom SOC" - это нумерация пинов внутри микросхемы 
GPIO.setmode(GPIO.BCM)

# задержка между импульсами отправляемые на драйвер ШД
delay = 0.0000001
# цикл настройки 0,11,9 пинов на выход 3.3v
for x in [0,11,9]:
    GPIO.setup(x,GPIO.OUT)

def motor_moving(direction):
    # задаём направление вращения ШД
    GPIO.output(11, direction)
    # отправляем на пин 0 3.3v (включение драйвера)
    GPIO.output(0, GPIO.HIGH)
    #цикл отправки последовательности импульсов 3.3v и 0v (1000 шагов ШД)
    for x in range(1000):
        GPIO.output(9, GPIO.HIGH)
        sleep(delay)
        GPIO.output(9, GPIO.LOW)
        sleep(delay)
# запуск вращения ШД
motor_moving(0);
# запуск вращения ШД в противоположную сторону
motor_moving(1);
#возращение пинов в 0v
GPIO.cleanup();
