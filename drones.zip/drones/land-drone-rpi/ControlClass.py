# from MotorClass import Motor
import keyboard
from threading import Event

class Control:
	all_flags = []

	def __init__(self, a=0, b=0, c=0):
		# self.motor = Motor(a, b, c)
		pass

	def keyboard_move(self, n):
		while self.all_flags[n]:
			if keyboard.is_pressed('w'):
				print("forward")
			elif keyboard.is_pressed('a'):
				print("left")
			elif keyboard.is_pressed('d'):
				print("right")
			elif keyboard.is_pressed('s'):
				print("back")


if __name__ == "__main__":
	con = Control()
	con.keyboard_move()
