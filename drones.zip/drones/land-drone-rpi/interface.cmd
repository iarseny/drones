
@echo off
rem This script was created by Nuitka to execute 'interface.exe' with Python DLL being found.
set PATH=C:\Users\User\AppData\Local\Programs\Python\PYTHON~1;%PATH%
set PYTHONHOME=C:\Users\User\AppData\Local\Programs\Python\Python311
"%~dp0interface.exe" %*
